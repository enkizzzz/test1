package com.example.test; //orders 객체 안 대기번호정보 들어감
public class Orders {
    private int WaitNumber;

    public Orders(){}

    public int getWaitNumber() {
        return WaitNumber;
    }

    public void setWaitNumber(int WaitNumber) {
        this.WaitNumber = WaitNumber;
    }


}